'use strict';
// Import faker module from node_modules
const faker = require('faker');

// Your function handler
module.exports.helloRandomNameHandler = function (event, context, cb) {
  const randomName = faker.name.firstName();
  const message = {
    message: 'Hello ' + randomName,
    event: event
  };
  cb(null, message);
};
